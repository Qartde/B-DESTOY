> Create Fork And Then Get Inside database, Edit Owner.json replace Your number And Commit Changes | If You Wana Add Premium Too, The Same Method Will Applies For It,Edit Premium.json. After Finishing This , Deploy And Enjoy.

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center">
 
### TUTORIAL OWNER/PREMIUM

<a href="https://youtu.be/qYv8p_hMb-w"><img src="https://img.shields.io/badge/YouTube-ff0000?style=for-the-badge&logo=youtube&logoColor=ff000000&link=https://youtu.be/qYv8p_hMb-w" /><br>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center">
 
<p align="center">
<a href="https://github.com/GlobalTechInfo"><img title="Author" src="https://i.ibb.co/jHynY57/11993dc55c32a21a249ef1721fb66af4.jpg?style=for-the-badge&logo=github"></a>
<p>

 <a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center">

  
<p align="center"><img src="https://profile-counter.glitch.me/{XeonBug-V8}/count.svg" alt="Qasim Ali :: Visitor's Count" /></p>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center">



<p align="center">
<a href="https://github.com/GlobalTechInfo/XeonBug-V8/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/GlobalTechInfo/XeonBug-V8?color=blue&style=flat-square"></a>
<a href="https://github.com/GlobalTechInfo/XeonBug-V8/network/members"><img title="Forks" src="https://img.shields.io/github/forks/GlobalTechInfo/XeonBug-V8?color=red&style=flat-square"></a>
<a href="https://github.com/GlobalTechInfo/XeonBug-V8/"><img title="Size" src="https://img.shields.io/github/repo-size/GlobalTechInfo/XeonBug-V8?style=flat-square&color=green"></a>
<a href="https://github.com/GlobalTechInfo/XeonBug-V8/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-yellow.svg"></a>&nbsp;&nbsp;
</p>
<p align='center'>
</p>

<p align="center">

  <a aria-label="Join our chats" href="https://t.me/GlobalBotInc" target="_blank">
    <img alt="telegram" src="https://img.shields.io/badge/Join Group-25D366?style=for-the-badge&logo=telegram&logoColor=white" />
  </a>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center">


# CLICK THE BUTTON TO FORK


<a href="https://github.com/GlobalTechInfo/XeonBug-V8/fork"><img title="XeonBug-V8" src="https://img.shields.io/badge/FORK-XeonBug V8-h?color=blue&style=for-the-badge&logo=stackshare"></a>


<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center">



### TUTORIAL TO HOST IN PANEL
<a href="https://youtu.be/Nqid24l1Z3I"><img src="https://img.shields.io/badge/YouTube-ff0000?style=for-the-badge&logo=youtube&logoColor=ff000000&link=https://youtu.be/Nqid24l1Z3I" /><br>

### BOT HOSTING PANEL LINK
<a href='https://bot-hosting.net/?aff=1097457675723341836' target="_blank"><img alt='Panel Link'
src='https://img.shields.io/badge/HOSTING%20PANEL-blue?style=for-the-badge&logo=Cloudflare&logoColor=white'/></a>

`AFTER YARN GET INSTALLED, REMOVE YOUR COMMAND FROM BASH FILE AND CHANGE BOT START FILE NAME FROM index.js TO main.js`

 <a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center">
 
 ### DEPLOY IN REPLIT

   <a href='https://repl.it/github/GlobalTechInfo/XeonBug-V8' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-REPLIT-orange?style=for-the-badge&logo=replit&logoColor=white'/></a>
  
   <a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center">

### TUTORIAL FOR CLOUD SHELL

<a href="https://youtu.be/nHnNCsuxYuA"><img src="https://img.shields.io/badge/YouTube-ff0000?style=for-the-badge&logo=youtube&logoColor=ff000000&link=https://youtu.be/nHnNCsuxYuA" /><br>


### DEPLOY IN CLOUD SHELL
<a href='https://cloud.google.com/shell/?aff=1097457675723341836' target="_blank"><img alt='Google Cloud'
src='https://img.shields.io/badge/Google_Cloud-4285F4?style=for-the-badge&logo=google-cloud&logoColor=white'/><a>
 
 <a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center">

### DEPLOY IN CODESPACE

<a href='https://github.com/codespaces/new' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/CODESPACE-h?color=navy&style=for-the-badge&logo=visualstudiocode'/></a></p>

 <a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center">

### DEPLOY IN RENDER

<a href='https://dashboard.render.com' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/RENDER-h?color=maroon&style=for-the-badge&logo=render'/></a></p>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center">
 
### TUTORIAL FOR TERMUX
<a href="https://youtu.be/LYpyutDn_9s"><img src="https://img.shields.io/badge/YouTube-ff0000?style=for-the-badge&logo=youtube&logoColor=ff000000&link=https://youtu.be/LYpyutDn_9s" /><br>

# DEPLOY IN TERMUX/UBUNTU
```
apt update && apt upgrade -y
```
```
pkg install proot-distro
```
```
proot-distro install ubuntu
```
```
proot-distro login ubuntu
```
```
apt update && apt upgrade -y
```
```
apt install -y webp git ffmpeg curl imagemagick
```
```
apt -y remove nodejs
curl -fsSl https://deb.nodesource.com/setup_lts.x | bash - && apt -y install nodejs
```
```
git clone https://github.com/<your gitHub Username>/Raiden-bugbot
cd Raiden-bugbot
```
```
npm install && npm start
```

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

